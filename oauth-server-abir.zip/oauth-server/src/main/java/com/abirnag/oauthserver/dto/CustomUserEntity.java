package com.abirnag.oauthserver.dto;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.abirnag.oauthserver.entities.Permission;
import com.abirnag.oauthserver.entities.UserEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CustomUserEntity extends UserEntity {
	
	Collection<GrantedAuthority> grantedAuthorities=new ArrayList<>();
	
	public CustomUserEntity(UserEntity ue ,List<Permission> lp) {
		super(ue.getId(), ue.getUsername(), ue.getPassword(), ue.getName());
		
		lp.forEach(p -> {
			
			GrantedAuthority ga = new SimpleGrantedAuthority(p.getPermission());
			grantedAuthorities.add(ga);
		});
	
	}

	

}
