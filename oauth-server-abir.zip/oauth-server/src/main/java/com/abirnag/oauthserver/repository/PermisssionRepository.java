package com.abirnag.oauthserver.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.abirnag.oauthserver.entities.Permission;

public interface PermisssionRepository extends JpaRepository<Permission, Integer>{
	
	@Query("select p from Permission p join RolePermission rp on p.id=rp.permissionId join UserRole ur  on rp.id= ur.roleId where ur.userId=:userId")
	List<Permission> findPermissionsForUserEntity(@Param("userId") Integer userId);

}
