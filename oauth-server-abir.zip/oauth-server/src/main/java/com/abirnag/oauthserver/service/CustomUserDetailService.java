package com.abirnag.oauthserver.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.abirnag.oauthserver.dto.CustomUser;
import com.abirnag.oauthserver.dto.CustomUserEntity;
import com.abirnag.oauthserver.entities.Permission;
import com.abirnag.oauthserver.entities.UserEntity;
import com.abirnag.oauthserver.repository.OauthRepository;
import com.abirnag.oauthserver.repository.PermisssionRepository;



@Service
public class CustomUserDetailService implements UserDetailsService {
	
	@Autowired
	private OauthRepository oauthRepo;
	@Autowired
	private PermisssionRepository permissionRepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<UserEntity> ue =  oauthRepo.findByUsername(username);
		if(ue.isPresent()) {
			List<Permission> permissions = permissionRepo.findPermissionsForUserEntity(ue.get().getId());
			CustomUserEntity cue = new CustomUserEntity(ue.get(),permissions);
			CustomUser cu = new CustomUser(cue);
			
			return cu;
			
			
		}else {
			throw new UsernameNotFoundException(username+ " username is not found in database");
		}
		
	}

}
