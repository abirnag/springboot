package com.abirnag.oauthserver.dto;

import org.springframework.security.core.userdetails.User;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomUser extends User {
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer userId;
	 private String name;

	
	 public CustomUser(CustomUserEntity ue){
		 super(ue.getUsername(), ue.getPassword(),ue.grantedAuthorities);
		 userId=ue.getId();
		 name=ue.getName();
	 }
}
